from tkinter import *
from random import choice

ask = ["hi","hey", "hello I am Weather Spaces"]
hi = ["hi","hey","hello I am Weather Spaces"]
huf = ["Goodbye"]
puppy = ["Goodbye ", "Thank You for using Weather Spaces","See you later"]
sq = ["what is the weather for the next few days"]
qs = ["This is the Weather for the next 3 days"]
rp = ["what is the weather for this location"]
pr = ["the weather in this location is ...."]
hr = ["who are you", "what is your name"]
rh = ["I am a chatbot created three Masterminds Immanuel , Devendra and Abdelnour"]
emotion = ["What is the weather on this date?","Can I check the weather is on this Date?"]
thought = ["The weather is on this Date","the weather for the next 3 days"]
express = ["What clothes should I bring ", "You should bring a Carhartt jacket , lee jeans and converse one star"]
press = ["You should bring a Carhartt jacket , tommy jeans and converse one star"]
ty = ["Can I check another location"]
vx = ["Yes what location would you like to check"]
lara = ["How are you?"]
manny = ["I am great thank you ! how are you :)?"]
error = ["sorry, I don't understand ", "what did you say?", "can't recognise"]

root = Tk()
user = StringVar()
bot = StringVar()

root.title("Weather SPACES")
Label(root, text=" user : ").pack(side=LEFT)
Entry(root, textvariable=user).pack(side=LEFT)
Label(root, text=" Bot  : ").pack(side=LEFT)
Entry(root, textvariable=bot).pack(side=LEFT)


def main():
    question = user.get()
    if question in ask:
        bot.set(choice(hi))
    elif question in huf:
        bot.set(choice(puppy))
    elif question in sq:
        bot.set(choice(qs))
    elif question in rp:
        bot.set(choice(pr))
    elif question in hr:
        bot.set(choice(rh))
    elif question in emotion:
        bot.set(choice(thought))
    elif question in express:
        bot.set(choice(press))
    elif question in ty:
        bot.set(choice(vx))
    elif question in lara:
        bot.set(choice(manny))

    else:
        bot.set(choice(error))


Button(root, text="talk", command=main).pack(side=LEFT)

mainloop()
