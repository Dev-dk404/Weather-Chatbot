import json
import requests
from datetime import datetime

# import main
location = input("Enter the city name: ")
url = "https://community-open-weather-map.p.rapidapi.com/forecast"

querystring = {"q": str(location), "units": "metric"}

headers = {
    'x-rapidapi-key': "6f437c8535mshe6510a20e0b9901p1e650ajsn100ed3e53427",
    'x-rapidapi-host': "community-open-weather-map.p.rapidapi.com"
}

response = requests.request("GET", url, headers=headers, params=querystring)
y = json.loads(response.text)

#
#
# #enter api below
# complete_api_link = "community-open-weather-map.p.rapidapi.com"+location+"&appid="+user_api
#
# api_link = requests.get(complete_api_link)
# api_data = api_link.json()

if response.status_code == '404':
    print("Connection Error,Please check your API key and URL")

elif y['cod'] == '404':
    print("Invalid City:{}, Please check your City name".format(location))

else:
    temp_city = (y['list'][0]['main']['temp'])
    max_temp = y['list'][0]['main']['temp_max']
    min_temp = y['list'][0]['main']['temp_min']
    weather_desc = y['list'][0]['weather'][0]['description']
    hmdt = y['list'][0]['main']['humidity']
    wind_spd = y['list'][0]['wind']['speed']
    date_time = datetime.now().strftime("%d %b %y | %I %p")
    country=y['city']['country']

    print("------------------------------------------------------")
    print("Weather Stats for - {},{},".format(location.upper(), date_time))
    print("------------------------------------------------------")
    print("Country:", country)
    print("Current temperature is: {:.2f} deg C".format(temp_city))
    print("Max temperature is: {:.2f} deg C".format(max_temp))
    print("Min temperature is: {:.2f} deg C".format(min_temp))
    print("Current weather desc :", weather_desc)
    print("Current Humidity      :", hmdt, '%')
    print("Current wind speed    :", wind_spd, 'kmph')
