import tkinter as tk
from tkinter import *
from tkinter.ttk import *
import tkinter.messagebox as msgbox
from random import choice


class Window(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SPACES WEATHER")
        self.label_text = tk.StringVar()
        self.label_text.set("Name: ")

        self.name_text = tk.StringVar()

        self.label = tk.Label(self, textvar=self.label_text)
        self.label.pack(fill=tk.BOTH, expand=1, padx=100, pady=10)

        self.name_entry = tk.Entry(self, textvar=self.name_text)
        self.name_entry.pack(fill=tk.BOTH, expand=1, padx=20, pady=20)

        hello_button = tk.Button(self, text="BEGIN", command=self.say_hello)
        hello_button.pack(side=tk.LEFT, padx=(20, 0), pady=(0, 20))

        goodbye_button = tk.Button(self, text="END", command=self.say_goodbye)
        goodbye_button.pack(side=tk.RIGHT, padx=(0, 20), pady=(0, 20))

    def say_hello(self):
        message = "Welcome " + self.name_entry.get()
        msgbox.showinfo("Hello", message)
        if msgbox.askyesno("Weather SPACES", "Do you want to enter the greatest weather app of all time?"):
            if __name__ == '__main__':
                import main
                #service.py executed as script
                # do something
                def say_hello(self):
                 main.pain()


    def say_goodbye(self):
        if msgbox.askyesno("Spaces Weather",  "This window will close"):
            message = "Window will self-destruct in 2 seconds - thank you " + self.name_entry.get()
            self.label_text.set(message)
            self.after(2000, self.destroy)
        else:
            msgbox.showinfo("Not Closing", "Great! you have entered the simulation.")


if __name__ == "__main__":
    window = Window()
    window.mainloop()
